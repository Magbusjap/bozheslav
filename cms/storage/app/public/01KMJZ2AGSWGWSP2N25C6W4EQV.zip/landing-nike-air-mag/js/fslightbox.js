!(function (e, t) {
	if ("object" == typeof exports && "object" == typeof module)
		module.exports = t();
	else if ("function" == typeof define && define.amd) define([], t);
	else {
		var n = t();
		for (var o in n) ("object" == typeof exports ? exports : e)[o] = n[o];
	}
})(window, function () {
	return (function (e) {
		var t = {};
		function n(o) {
			if (t[o]) return t[o].exports;
			var i = (t[o] = { i: o, l: !1, exports: {} });
			return (e[o].call(i.exports, i, i.exports, n), (i.l = !0), i.exports);
		}
		return (
			(n.m = e),
			(n.c = t),
			(n.d = function (e, t, o) {
				n.o(e, t) || Object.defineProperty(e, t, { enumerable: !0, get: o });
			}),
			(n.r = function (e) {
				("undefined" != typeof Symbol &&
					Symbol.toStringTag &&
					Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }),
					Object.defineProperty(e, "__esModule", { value: !0 }));
			}),
			(n.t = function (e, t) {
				if ((1 & t && (e = n(e)), 8 & t)) return e;
				if (4 & t && "object" == typeof e && e && e.__esModule) return e;
				var o = Object.create(null);
				if (
					(n.r(o),
					Object.defineProperty(o, "default", { enumerable: !0, value: e }),
					2 & t && "string" != typeof e)
				)
					for (var i in e)
						n.d(
							o,
							i,
							function (t) {
								return e[t];
							}.bind(null, i),
						);
				return o;
			}),
			(n.n = function (e) {
				var t =
					e && e.__esModule
						? function () {
								return e.default;
							}
						: function () {
								return e;
							};
				return (n.d(t, "a", t), t);
			}),
			(n.o = function (e, t) {
				return Object.prototype.hasOwnProperty.call(e, t);
			}),
			(n.p = ""),
			n((n.s = 0))
		);
	})([
		function (e, t, n) {
			"use strict";
			n.r(t);
			var o,
				i = "fslightbox-",
				s = "".concat(i, "styles"),
				r = "".concat(i, "cursor-grabbing"),
				a = "".concat(i, "full-dimension"),
				c = "".concat(i, "flex-centered"),
				l = "".concat(i, "open"),
				u = "".concat(i, "transform-transition"),
				d = "".concat(i, "absoluted"),
				f = "".concat(i, "slide-btn"),
				p = "".concat(f, "-container"),
				h = "".concat(i, "fade-in"),
				g = "".concat(i, "fade-out"),
				m = h + "-strong",
				b = g + "-strong",
				v = "".concat(i, "opacity-"),
				x = "".concat(v, "1"),
				y = "".concat(i, "source");
			function w(e) {
				return (w =
					"function" == typeof Symbol && "symbol" == typeof Symbol.iterator
						? function (e) {
								return typeof e;
							}
						: function (e) {
								return e &&
									"function" == typeof Symbol &&
									e.constructor === Symbol &&
									e !== Symbol.prototype
									? "symbol"
									: typeof e;
							})(e);
			}
			function S(e) {
				var t = e.stageIndexes,
					n = e.core.stageManager,
					o = e.props.sources.length - 1;
				((n.getPreviousSlideIndex = function () {
					return 0 === t.current ? o : t.current - 1;
				}),
					(n.getNextSlideIndex = function () {
						return t.current === o ? 0 : t.current + 1;
					}),
					(n.updateStageIndexes =
						0 === o
							? function () {}
							: 1 === o
								? function () {
										0 === t.current
											? ((t.next = 1), delete t.previous)
											: ((t.previous = 0), delete t.next);
									}
								: function () {
										((t.previous = n.getPreviousSlideIndex()),
											(t.next = n.getNextSlideIndex()));
									}),
					(n.i =
						o <= 2
							? function () {
									return !0;
								}
							: function (e) {
									var n = t.current;
									if ((0 === n && e === o) || (n === o && 0 === e)) return !0;
									var i = n - e;
									return -1 === i || 0 === i || 1 === i;
								}));
			}
			"object" === ("undefined" == typeof window ? "undefined" : w(window)) &&
				(((o = document.createElement("style")).className = s),
				o.appendChild(
					document.createTextNode(
						".fslightbox-absoluted{position:absolute;top:0;left:0}.fslightbox-fade-in{animation:fslightbox-fade-in .3s cubic-bezier(0,0,.7,1)}.fslightbox-fade-out{animation:fslightbox-fade-out .3s ease}.fslightbox-fade-in-strong{animation:fslightbox-fade-in-strong .3s cubic-bezier(0,0,.7,1)}.fslightbox-fade-out-strong{animation:fslightbox-fade-out-strong .3s ease}@keyframes fslightbox-fade-in{from{opacity:.65}to{opacity:1}}@keyframes fslightbox-fade-out{from{opacity:.35}to{opacity:0}}@keyframes fslightbox-fade-in-strong{from{opacity:.3}to{opacity:1}}@keyframes fslightbox-fade-out-strong{from{opacity:1}to{opacity:0}}.fslightbox-cursor-grabbing{cursor:grabbing}.fslightbox-full-dimension{width:100%;height:100%}.fslightbox-open{overflow:hidden;height:100%}.fslightbox-flex-centered{display:flex;justify-content:center;align-items:center}.fslightbox-opacity-0{opacity:0!important}.fslightbox-opacity-1{opacity:1!important}.fslightbox-scrollbarfix{padding-right:17px}.fslightbox-transform-transition{transition:transform .3s}.fslightbox-container::backdrop{display:none}.fslightbox-container{font-family:Arial,sans-serif;position:fixed;top:0;left:0;padding:0;border:0;max-width:none;max-height:none;background:linear-gradient(rgba(30,30,30,.9),#000 1810%);touch-action:pinch-zoom;overflow:hidden;z-index:1000000000;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;-webkit-tap-highlight-color:transparent}.fslightbox-container *{box-sizing:border-box}.fslightbox-svg{width:20px;height:20px}.fslightbox-svgp{transition:fill .15s ease;fill:#ddd}.fslightbox-nav{height:45px;width:100%;position:absolute;top:0;left:0}.fslightboxsn{z-index:0;display:flex;align-items:center;margin:14px 0 0 11px;font-size:15px;color:#d7d7d7}.fslightboxsn span{display:inline;vertical-align:middle}.fslightboxsl{display:inline-block!important;margin:0 5px;width:1px;height:12px;transform:rotate(15deg);background:white}.fslightbox-toolbar{position:absolute;z-index:3;right:0;top:0;height:100%;display:flex}.fslightbox-toolbar-button{width:45px;height:100%}.fslightbox-fsx{width:24px;height:24px}.fslightboxb{border:0;background:rgba(35,35,35,.65);cursor:pointer}.fslightboxb:focus{outline:0}.fslightboxb:focus .fslightbox-svgp{fill:#fff}.fslightboxb:hover .fslightbox-svgp{fill:#fff}.fslightbox-slide-btn-container{display:flex;align-items:center;padding:12px 12px 12px 6px;position:absolute;top:50%;cursor:pointer;z-index:3;transform:translateY(-50%)}.fslightbox-slide-btn-container-next{right:0;padding-left:12px;padding-right:3px}@media (min-width:476px){.fslightbox-slide-btn-container{padding:22px 22px 22px 6px}.fslightbox-slide-btn-container-next{padding-right:6px!important;padding-left:22px}}@media (min-width:768px){.fslightbox-slide-btn-container{padding:30px 30px 30px 6px}.fslightbox-slide-btn-container-next{padding-left:30px}.fslightbox-slide-btn{padding:10px}}.fslightbox-slide-btn-container:hover .fslightbox-svgp{fill:#fff}.fslightbox-slide-btn{padding:9px}.fslightbox-slide-btn-container-previous{left:0}@media (max-width:475.99px){.fslightbox-slide-btn-container-previous{padding-left:3px}}.fslightbox-down-event-detector{position:absolute;z-index:1}.fslightbox-slide-swiping-hoverer{z-index:4}.fslightbox-invalid-file-wrapper{font-size:22px;color:#eaebeb;margin:auto}.fslightboxv{object-fit:cover}.fslightbox-youtube-iframe{border:0}.fslightboxl{display:block;margin:auto;position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:67px;height:67px}.fslightboxl div{box-sizing:border-box;display:block;position:absolute;width:54px;height:54px;margin:6px;border:5px solid;border-color:#999 transparent transparent transparent;border-radius:50%;animation:fslightboxl 1.2s cubic-bezier(.5,0,.5,1) infinite}.fslightboxl div:nth-child(1){animation-delay:-.45s}.fslightboxl div:nth-child(2){animation-delay:-.3s}.fslightboxl div:nth-child(3){animation-delay:-.15s}@keyframes fslightboxl{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}.fslightbox-source{position:relative;z-index:2;opacity:0}@media (min-width:1200px){.fslightboxsn{margin:15px 0 0 12px;font-size:16px;display:block}.fslightboxsl{margin:0 6px 1px 6px;height:14px}.fslightbox-slide-btn{padding:11px}.fslightbox-svg{width:22px;height:22px}.fslightbox-fsx{width:26px;height:26px}.fslightbox-fso{width:22px;height:22px}.fslightboxl div{width:60px;height:60px;border-width:6px;border-color:#999 transparent transparent transparent;border-radius:50%}}@media (min-width:1600px){.fslightbox-nav{height:50px}.fslightboxsn{display:flex;margin:19px 0 0 16px;font-size:20px}.fslightboxsl{margin:0 7px 1px 7px;height:16px;width:2px;background:#d7d7d7}.fslightbox-toolbar-button{width:50px}.fslightbox-slide-btn{padding:12px}.fslightbox-svg{width:24px;height:24px}.fslightbox-fsx{width:28px;height:28px}.fslightbox-fso{width:24px;height:24px}}",
					),
				),
				document.head.appendChild(o));
			function L(e) {
				var t,
					n = e.props,
					o = 0,
					i = {};
				((this.getSourceTypeFromLocalStorageByUrl = function (e) {
					return t[e] ? t[e] : s(e);
				}),
					(this.handleReceivedSourceTypeForUrl = function (e, n) {
						if (
							!1 === i[n] &&
							(o--, "invalid" !== e ? (i[n] = e) : delete i[n], 0 === o)
						) {
							!(function (e, t) {
								for (var n in t) e[n] = t[n];
							})(t, i);
							try {
								localStorage.setItem("fslightbox-types", JSON.stringify(t));
							} catch (e) {}
						}
					}));
				var s = function (e) {
					(o++, (i[e] = !1));
				};
				if (n.disableLocalStorage)
					((this.getSourceTypeFromLocalStorageByUrl = function () {}),
						(this.handleReceivedSourceTypeForUrl = function () {}));
				else {
					try {
						t = JSON.parse(localStorage.getItem("fslightbox-types"));
					} catch (e) {}
					t || ((t = {}), (this.getSourceTypeFromLocalStorageByUrl = s));
				}
			}
			function C(e, t, n, o) {
				e.data;
				var i = e.elements.sources,
					s = n / o,
					r = 0;
				this.adjustSize = function () {
					if ((r = e.mw / s) < e.mh) return (n < e.mw && (r = o), a());
					((r = o > e.mh ? e.mh : o), a());
				};
				var a = function () {
					((i[t].style.width = r * s + "px"), (i[t].style.height = r + "px"));
				};
			}
			function A(e, t) {
				var n = this,
					o = e.collections.sourceSizers,
					i = e.elements,
					s = i.sourceAnimationWrappers,
					r = i.sources,
					a = e.isl,
					c = e.props.onSourceLoad,
					l = e.resolve;
				function u(e, n) {
					((o[t] = l(C, [t, e, n])), o[t].adjustSize());
				}
				((this.b = function (e, o) {
					(r[t].classList.add(x), n.a(), u(e, o), (n.b = u));
				}),
					(this.a = function () {
						((a[t] = !0),
							s[t].classList.add(m),
							s[t].removeChild(s[t].firstChild),
							c && c(e, r[t], t));
					}));
			}
			function E(e, t) {
				var n,
					o = this,
					i = e.elements.sources,
					s = e.props,
					r = (0, e.resolve)(A, [t]);
				((this.handleImageLoad = function (e) {
					var t = e.target,
						n = t.naturalWidth,
						o = t.naturalHeight;
					r.b(n, o);
				}),
					(this.handleVideoLoad = function (e) {
						var t = e.target,
							o = t.videoWidth,
							i = t.videoHeight;
						((n = !0), r.b(o, i));
					}),
					(this.handleNotMetaDatedVideoLoad = function () {
						n || o.handleYoutubeLoad();
					}),
					(this.handleYoutubeLoad = function (e, t) {
						(e || ((e = 1920), (t = 1080)),
							s.maxYoutubeDimensions &&
								((e = s.maxYoutubeDimensions.width),
								(t = s.maxYoutubeDimensions.height)),
							r.b(e, t));
					}),
					(this.handleCustomLoad = function () {
						var e = i[t],
							n = e.offsetWidth,
							s = e.offsetHeight;
						n && s ? r.b(n, s) : setTimeout(o.handleCustomLoad);
					}));
			}
			function F(e, t, n) {
				var o = e.elements.sources,
					i = e.props.customClasses,
					s = i[t] ? i[t] : "";
				o[t].className = n + " " + s;
			}
			function I(e, t) {
				var n = e.elements.sources,
					o = e.props.customAttributes;
				for (var i in o[t]) n[t].setAttribute(i, o[t][i]);
			}
			function z(e, t) {
				var n = e.collections.sourceLoadHandlers,
					o = e.elements,
					i = o.sources,
					s = o.sourceAnimationWrappers,
					r = e.props.sources;
				((i[t] = document.createElement("img")),
					F(e, t, y),
					(i[t].src = r[t]),
					(i[t].onload = n[t].handleImageLoad),
					I(e, t),
					s[t].appendChild(i[t]));
			}
			function T(e, t) {
				var n = e.ap,
					o = e.collections.sourceLoadHandlers,
					i = e.elements,
					s = i.sources,
					r = i.sourceAnimationWrappers,
					a = e.props,
					c = a.sources,
					l = a.videosPosters,
					u = document.createElement("video"),
					d = document.createElement("source");
				((s[t] = u),
					F(e, t, "".concat(y, " fslightboxv")),
					(u.src = c[t]),
					(u.onloadedmetadata = function (e) {
						return o[t].handleVideoLoad(e);
					}),
					(u.controls = !0),
					(u.autoplay = n.i(t)),
					I(e, t),
					l[t] && (s[t].poster = l[t]),
					(d.src = c[t]),
					u.appendChild(d),
					setTimeout(o[t].handleNotMetaDatedVideoLoad, 3e3),
					r[t].appendChild(s[t]));
			}
			function N(e, t) {
				var n = e.ap,
					o = e.collections.sourceLoadHandlers,
					s = e.elements,
					r = s.sources,
					a = s.sourceAnimationWrappers,
					c = e.props.sources[t],
					l = c.split("?")[1],
					u = document.createElement("iframe");
				((r[t] = u),
					F(e, t, "".concat(y, " ").concat(i, "youtube-iframe")),
					(u.src = "https://www.youtube.com/embed/"
						.concat(
							c.match(
								/^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/,
							)[2],
							"?",
						)
						.concat(l || "")
						.concat(n.i(t) ? "&mute=1&autoplay=1" : "", "&enablejsapi=1")),
					(u.allowFullscreen = !0),
					I(e, t),
					a[t].appendChild(u),
					o[t].handleYoutubeLoad(parseInt(u.width), parseInt(u.height)));
			}
			function P(e, t) {
				var n = e.collections.sourceLoadHandlers,
					o = e.elements,
					i = o.sources,
					s = o.sourceAnimationWrappers,
					r = e.props.sources;
				((i[t] = r[t]),
					F(e, t, "".concat(i[t].className, " ").concat(y)),
					s[t].appendChild(i[t]),
					n[t].handleCustomLoad());
			}
			function k(e, t) {
				var n = e.elements,
					o = n.sources,
					s = n.sourceAnimationWrappers;
				e.props.sources;
				((o[t] = document.createElement("div")),
					(o[t].className = "".concat(i, "invalid-file-wrapper ").concat(c)),
					(o[t].innerHTML = "Invalid source"),
					s[t].appendChild(o[t]),
					new A(e, t).a());
			}
			function R(e) {
				var t = e.collections,
					n = t.sourceLoadHandlers,
					o = t.sourcesRenderFunctions,
					i = e.core.sourceDisplayFacade,
					s = e.resolve;
				this.runActionsForSourceTypeAndIndex = function (t, r) {
					var a;
					switch (("invalid" !== t && (n[r] = s(E, [r])), t)) {
						case "image":
							a = z;
							break;
						case "video":
							a = T;
							break;
						case "youtube":
							a = N;
							break;
						case "custom":
							a = P;
							break;
						default:
							a = k;
					}
					((o[r] = function () {
						return a(e, r);
					}),
						i.displaySourcesWhichShouldBeDisplayed());
				};
			}
			function M(e, t, n) {
				var o = e.props,
					i = o.types,
					s = o.type,
					r = o.sources;
				((this.getTypeSetByClientForIndex = function (e) {
					var t;
					return (i && i[e] ? (t = i[e]) : s && (t = s), t);
				}),
					(this.retrieveTypeWithXhrForIndex = function (e) {
						!(function (e, t) {
							var n = document.createElement("a");
							n.href = e;
							var o = n.hostname;
							if ("www.youtube.com" === o || "youtu.be" === o)
								return t("youtube");
							var i = new XMLHttpRequest();
							((i.onreadystatechange = function () {
								if (4 !== i.readyState) {
									if (2 === i.readyState) {
										var e,
											n = i.getResponseHeader("content-type");
										switch (n.slice(0, n.indexOf("/"))) {
											case "image":
												e = "image";
												break;
											case "video":
												e = "video";
												break;
											default:
												e = "invalid";
										}
										((i.onreadystatechange = null), i.abort(), t(e));
									}
								} else t("invalid");
							}),
								i.open("GET", e),
								i.send());
						})(r[e], function (o) {
							(t.handleReceivedSourceTypeForUrl(o, r[e]),
								n.runActionsForSourceTypeAndIndex(o, e));
						});
					}));
			}
			function H(e, t) {
				var n = e.core.stageManager,
					o = e.elements,
					i = o.smw,
					s = o.sourceWrappersContainer,
					r = e.props,
					l = 0,
					f = document.createElement("div");
				function p(e) {
					((f.style.transform = "translateX(".concat(e + l, "px)")), (l = 0));
				}
				function h() {
					return (1 + r.slideDistance) * innerWidth;
				}
				((f.className = "".concat(d, " ").concat(a, " ").concat(c)),
					(f.s = function () {
						f.style.display = "flex";
					}),
					(f.h = function () {
						f.style.display = "none";
					}),
					(f.a = function () {
						f.classList.add(u);
					}),
					(f.d = function () {
						f.classList.remove(u);
					}),
					(f.n = function () {
						f.style.removeProperty("transform");
					}),
					(f.v = function (e) {
						return ((l = e), f);
					}),
					(f.ne = function () {
						p(-h());
					}),
					(f.z = function () {
						p(0);
					}),
					(f.p = function () {
						p(h());
					}),
					n.i(t) || f.h(),
					(i[t] = f),
					s.appendChild(f),
					(function (e, t) {
						var n = e.elements,
							o = n.smw,
							i = n.sourceAnimationWrappers,
							s = document.createElement("div"),
							r = document.createElement("div");
						r.className = "fslightboxl";
						for (var a = 0; a < 3; a++) {
							var c = document.createElement("div");
							r.appendChild(c);
						}
						(s.appendChild(r), o[t].appendChild(s), (i[t] = s));
					})(e, t));
			}
			function W(e, t, n) {
				var o = document.createElementNS("http://www.w3.org/2000/svg", "svg"),
					s = "".concat(i, "svg");
				(o.setAttributeNS(null, "class", "".concat(s)),
					o.setAttributeNS(null, "viewBox", t));
				var r = document.createElementNS("http://www.w3.org/2000/svg", "path");
				return (
					r.setAttributeNS(null, "class", "".concat(s, "p")),
					r.setAttributeNS(null, "d", n),
					o.appendChild(r),
					e.appendChild(o),
					o
				);
			}
			function D(e, t) {
				var n = document.createElement("button");
				return (
					(n.className = "fslightboxb ".concat(i, "toolbar-button ").concat(c)),
					(n.title = t),
					e.appendChild(n),
					n
				);
			}
			function O(e, t) {
				var n = document.createElement("div");
				((n.className = "".concat(i, "toolbar")),
					t.appendChild(n),
					(function (e, t) {
						if (!e.hfs) {
							var n =
									"M4.5 11H3v4h4v-1.5H4.5V11zM3 7h1.5V4.5H7V3H3v4zm10.5 6.5H11V15h4v-4h-1.5v2.5zM11 3v1.5h2.5V7H15V3h-4z",
								o = D(t);
							o.title = "Enter fullscreen";
							var s = W(o, "0 0 18 18", n);
							((e.fso = function () {
								((e.ifs = 1),
									(o.title = "Exit fullscreen"),
									s.classList.add("".concat(i, "fsx")),
									s.setAttributeNS(null, "viewBox", "0 0 950 1024"),
									s.firstChild.setAttributeNS(
										null,
										"d",
										"M682 342h128v84h-212v-212h84v128zM598 810v-212h212v84h-128v128h-84zM342 342v-128h84v212h-212v-84h128zM214 682v-84h212v212h-84v-128h-128z",
									));
							}),
								(e.fsx = function () {
									((e.ifs = 0),
										(o.title = "Enter fullscreen"),
										s.classList.remove("".concat(i, "fsx")),
										s.setAttributeNS(null, "viewBox", "0 0 18 18"),
										s.firstChild.setAttributeNS(null, "d", n));
								}),
								(o.onclick = e.fs.t));
						}
					})(e, n),
					(function (e, t) {
						var n = D(t, "Close");
						((n.onclick = e.core.lightboxCloser.closeLightbox),
							W(
								n,
								"0 0 24 24",
								"M 4.7070312 3.2929688 L 3.2929688 4.7070312 L 10.585938 12 L 3.2929688 19.292969 L 4.7070312 20.707031 L 12 13.414062 L 19.292969 20.707031 L 20.707031 19.292969 L 13.414062 12 L 20.707031 4.7070312 L 19.292969 3.2929688 L 12 10.585938 L 4.7070312 3.2929688 z",
							));
					})(e, n));
			}
			function j(e) {
				var t = e.props.sources,
					n = e.elements.container,
					o = document.createElement("div");
				((o.className = "".concat(i, "nav")),
					n.appendChild(o),
					O(e, o),
					t.length > 1 &&
						(function (e, t) {
							var n = e.props.sources,
								o = (e.stageIndexes, document.createElement("div")),
								i = document.createElement("span"),
								s = document.createElement("span"),
								r = document.createElement("span");
							((o.className = "fslightboxsn"),
								(e.sn = function (e) {
									return (i.innerHTML = e);
								}),
								(s.className = "fslightboxsl"),
								(r.innerHTML = n.length),
								o.appendChild(i),
								o.appendChild(s),
								o.appendChild(r),
								t.appendChild(o));
						})(e, o));
			}
			function X(e, t, n, o) {
				var i = e.elements.container,
					s = n.charAt(0).toUpperCase() + n.slice(1),
					r = document.createElement("div");
				((r.className = "".concat(p, " ").concat(p, "-").concat(n)),
					(r.title = "".concat(s, " slide")),
					(r.onclick = t),
					(function (e, t) {
						var n = document.createElement("button");
						((n.className = "fslightboxb ".concat(f, " ").concat(c)),
							W(n, "0 0 20 20", t),
							e.appendChild(n));
					})(r, o),
					i.appendChild(r));
			}
			function q(e) {
				var t = e.core,
					n = t.lightboxCloser,
					o = t.slideChangeFacade,
					i = e.fs;
				this.listener = function (e) {
					switch (e.key) {
						case "Escape":
							n.closeLightbox();
							break;
						case "ArrowLeft":
							o.changeToPrevious();
							break;
						case "ArrowRight":
							o.changeToNext();
							break;
						case "F11":
							(e.preventDefault(), i.t());
					}
				};
			}
			function B(e) {
				var t = e.elements,
					n = e.sourcePointerProps,
					o = e.stageIndexes;
				function i(e, o) {
					t.smw[e].v(n.swipedX)[o]();
				}
				this.runActionsForEvent = function (e) {
					var s, a, c;
					(t.container.contains(t.slideSwipingHoverer) ||
						t.container.appendChild(t.slideSwipingHoverer),
						(s = t.container),
						(a = r),
						(c = s.classList).contains(a) || c.add(a),
						(n.swipedX = e.screenX - n.downScreenX));
					var l = o.previous,
						u = o.next;
					(i(o.current, "z"),
						void 0 !== l && n.swipedX > 0
							? i(l, "ne")
							: void 0 !== u && n.swipedX < 0 && i(u, "p"));
				};
			}
			function V(e) {
				var t = e.dss,
					n = e.props.sources,
					o = e.resolve,
					i = e.sourcePointerProps,
					s = o(B);
				1 === n.length || t
					? (this.listener = function () {
							i.swipedX = 1;
						})
					: (this.listener = function (e) {
							i.isPointering && s.runActionsForEvent(e);
						});
			}
			function U(e) {
				var t = e.core.slideIndexChanger,
					n = e.elements.smw,
					o = e.stageIndexes,
					i = e.sws;
				function s(e) {
					var t = n[o.current];
					(t.a(), t[e]());
				}
				function r(e, t) {
					void 0 !== e && (n[e].s(), n[e][t]());
				}
				((this.runPositiveSwipedXActions = function () {
					var e = o.previous;
					if (void 0 === e) s("z");
					else {
						s("p");
						var n = o.next;
						t.changeTo(e);
						var a = o.previous;
						(i.d(a), i.b(n), s("z"), r(a, "ne"));
					}
				}),
					(this.runNegativeSwipedXActions = function () {
						var e = o.next;
						if (void 0 === e) s("z");
						else {
							s("ne");
							var n = o.previous;
							t.changeTo(e);
							var a = o.next;
							(i.d(a), i.b(n), s("z"), r(a, "p"));
						}
					}));
			}
			function _(e, t) {
				e.contains(t) && e.removeChild(t);
			}
			function Y(e) {
				var t = e.core.lightboxCloser,
					n = e.dss,
					o = e.elements,
					i = e.props,
					s = e.resolve,
					a = e.sourcePointerProps,
					c = s(U);
				((this.runNoSwipeActions = function () {
					(_(o.container, o.slideSwipingHoverer),
						a.isSourceDownEventTarget ||
							i.disableBackgroundClose ||
							t.closeLightbox(),
						(a.isPointering = !1));
				}),
					(this.runActions = function () {
						(n ||
							(a.swipedX > 0
								? c.runPositiveSwipedXActions()
								: c.runNegativeSwipedXActions()),
							_(o.container, o.slideSwipingHoverer),
							o.container.classList.remove(r),
							(a.isPointering = !1));
					}));
			}
			function J(e) {
				var t = e.resolve,
					n = e.sourcePointerProps,
					o = t(Y);
				this.listener = function () {
					n.isPointering &&
						(n.swipedX ? o.runActions() : o.runNoSwipeActions());
				};
			}
			function G(e) {
				var t = this,
					n = e.core,
					o = n.globalEventsController,
					i = n.scrollbarRecompensor,
					s = (e.data, e.e),
					r = e.elements,
					a = e.fs,
					c = e.props,
					u = e.sourcePointerProps,
					d = e.ud;
				this.runActions = function () {
					((t.i = 1),
						r.container.classList.add(b),
						o.removeListeners(),
						c.exitFullscreenOnClose && e.ifs && a.x(),
						setTimeout(function () {
							((t.i = 0),
								(u.isPointering = !1),
								r.container.classList.remove(b),
								document.documentElement.classList.remove(l),
								i.removeRecompense(),
								d && r.container.close(),
								document.body.removeChild(r.container),
								s("onClose"));
						}, 270));
				};
			}
			function $(e, t) {
				var n = e.classList;
				n.contains(t) && n.remove(t);
			}
			function K(e) {
				var t, n, o, i, s, r, a, c, l;
				(!(function (e) {
					var t = e.ap,
						n = e.elements.sources,
						o = e.props,
						i = o.autoplay,
						s = o.autoplays;
					function r(e, o) {
						if ("play" != o || t.i(e)) {
							var i = n[e];
							if (i) {
								var s = i.tagName;
								if ("VIDEO" == s) i[o]();
								else if ("IFRAME" == s) {
									var r = i.contentWindow;
									r &&
										r.postMessage(
											'{"event":"command","func":"'.concat(
												o,
												'Video","args":""}',
											),
											"*",
										);
								}
							}
						}
					}
					((t.i = function (e) {
						return s[e] || (i && 0 != s[e]);
					}),
						(t.p = function (e) {
							r(e, "play");
						}),
						(t.c = function (e, t) {
							(r(e, "pause"), r(t, "play"));
						}));
				})(e),
					(function (e) {
						e.data;
						var t = e.fs,
							n = [
								"fullscreenchange",
								"webkitfullscreenchange",
								"mozfullscreenchange",
								"MSFullscreenChange",
							],
							o = document.documentElement,
							i = o.requestFullscreen;
						function s(e) {
							for (var t = 0; t < n.length; t++) document[e](n[t], r);
						}
						function r() {
							document.fullscreenElement ||
							document.webkitIsFullScreen ||
							document.mozFullScreen ||
							document.msFullscreenElement
								? e.fso()
								: e.fsx();
						}
						t.i = function () {
							if (
								(i || (i = o.mozRequestFullScreen),
								i || (i = o.webkitRequestFullscreen),
								i || (i = o.msRequestFullscreen),
								!i)
							)
								return (
									(e.hfs = 1),
									(t.o = function () {}),
									(t.x = function () {}),
									(t.t = function () {}),
									(t.l = function () {}),
									void (t.q = function () {})
								);
							((t.o = function () {
								e.fso();
								var t = document.documentElement;
								t.requestFullscreen
									? t.requestFullscreen()
									: t.mozRequestFullScreen
										? t.mozRequestFullScreen()
										: t.webkitRequestFullscreen
											? t.webkitRequestFullscreen()
											: t.msRequestFullscreen && t.msRequestFullscreen();
							}),
								(t.x = function () {
									(e.fsx(),
										document.exitFullscreen
											? document.exitFullscreen()
											: document.mozCancelFullScreen
												? document.mozCancelFullScreen()
												: document.webkitExitFullscreen
													? document.webkitExitFullscreen()
													: document.msExitFullscreen &&
														document.msExitFullscreen());
								}),
								(t.t = function () {
									e.ifs ? t.x() : t.o();
								}),
								(t.l = function () {
									s("addEventListener");
								}),
								(t.q = function () {
									s("removeEventListener");
								}));
						};
					})(e),
					(n = (t = e).core),
					(o = n.globalEventsController),
					(i = n.windowResizeActioner),
					(s = t.fs),
					(r = t.resolve),
					(a = r(q)),
					(c = r(V)),
					(l = r(J)),
					(o.attachListeners = function () {
						(document.addEventListener("pointermove", c.listener),
							document.addEventListener("pointerup", l.listener),
							addEventListener("resize", i.runActions),
							document.addEventListener("keydown", a.listener),
							s.l());
					}),
					(o.removeListeners = function () {
						(document.removeEventListener("pointermove", c.listener),
							document.removeEventListener("pointerup", l.listener),
							removeEventListener("resize", i.runActions),
							document.removeEventListener("keydown", a.listener),
							s.q());
					}),
					(function (e) {
						var t = e.core.lightboxCloser,
							n = (0, e.resolve)(G);
						t.closeLightbox = function () {
							n.isLightboxFadingOut || n.runActions();
						};
					})(e),
					(function (e) {
						var t = e.data,
							n = e.core.scrollbarRecompensor;
						function o() {
							document.body.offsetHeight > innerHeight &&
								(document.body.style.marginRight = t.scrollbarWidth + "px");
						}
						((n.addRecompense = function () {
							"complete" === document.readyState
								? o()
								: addEventListener("load", function () {
										(o(), (n.addRecompense = o));
									});
						}),
							(n.removeRecompense = function () {
								document.body.style.removeProperty("margin-right");
							}));
					})(e),
					(function (e) {
						var t = e.core,
							n = t.slideChangeFacade,
							o = t.slideIndexChanger,
							i = t.stageManager;
						e.props.sources.length > 1
							? ((n.changeToPrevious = function () {
									o.jumpTo(i.getPreviousSlideIndex());
								}),
								(n.changeToNext = function () {
									o.jumpTo(i.getNextSlideIndex());
								}))
							: ((n.changeToPrevious = function () {}),
								(n.changeToNext = function () {}));
					})(e),
					(function (e) {
						var t = e.ap,
							n = (e.componentsServices, e.core),
							o = n.slideIndexChanger,
							i = n.sourceDisplayFacade,
							s = n.stageManager,
							r = e.elements,
							a = r.smw,
							c = r.sourceAnimationWrappers,
							l = e.isl,
							u = e.stageIndexes,
							d = e.sws;
						((o.changeTo = function (n) {
							(t.c(u.current, n),
								(u.current = n),
								s.updateStageIndexes(),
								e.sn(n + 1),
								i.displaySourcesWhichShouldBeDisplayed());
						}),
							(o.jumpTo = function (e) {
								var t = u.previous,
									n = u.current,
									i = u.next,
									r = l[n],
									f = l[e];
								o.changeTo(e);
								for (var p = 0; p < a.length; p++) a[p].d();
								(d.d(n),
									d.c(),
									requestAnimationFrame(function () {
										requestAnimationFrame(function () {
											var e = u.previous,
												o = u.next;
											function p() {
												s.i(n)
													? n === u.previous
														? a[n].ne()
														: n === u.next && a[n].p()
													: (a[n].h(), a[n].n());
											}
											(r && c[n].classList.add(g),
												f && c[u.current].classList.add(h),
												d.a(),
												void 0 !== e && e !== n && a[e].ne(),
												a[u.current].n(),
												void 0 !== o && o !== n && a[o].p(),
												d.b(t),
												d.b(i),
												l[n] ? setTimeout(p, 260) : p());
										});
									}));
							}));
					})(e),
					(function (e) {
						var t = e.core.sourcesPointerDown,
							n = e.elements,
							o = n.smw,
							i = n.sources,
							s = e.sourcePointerProps,
							r = e.stageIndexes;
						t.listener = function (e) {
							("VIDEO" !== e.target.tagName && e.preventDefault(),
								(s.isPointering = !0),
								(s.downScreenX = e.screenX),
								(s.swipedX = 0));
							var t = i[r.current];
							t && t.contains(e.target)
								? (s.isSourceDownEventTarget = !0)
								: (s.isSourceDownEventTarget = !1);
							for (var n = 0; n < o.length; n++) o[n].d();
						};
					})(e),
					(function (e) {
						var t = e.collections.sourcesRenderFunctions,
							n = e.core.sourceDisplayFacade,
							o = e.loc,
							i = e.stageIndexes;
						function s(e) {
							t[e] && (t[e](), delete t[e]);
						}
						n.displaySourcesWhichShouldBeDisplayed = function () {
							if (o) s(i.current);
							else for (var e in i) s(i[e]);
						};
					})(e),
					(function (e) {
						var t = e.core.stageManager,
							n = e.elements,
							o = n.smw,
							i = n.sourceAnimationWrappers,
							s = e.isl,
							r = e.stageIndexes,
							a = e.sws;
						((a.a = function () {
							for (var e in r) o[r[e]].s();
						}),
							(a.b = function (e) {
								void 0 === e || t.i(e) || (o[e].h(), o[e].n());
							}),
							(a.c = function () {
								for (var e in r) a.d(r[e]);
							}),
							(a.d = function (e) {
								if (s[e]) {
									var t = i[e];
									($(t, m), $(t, h), $(t, g));
								}
							}));
					})(e),
					(function (e) {
						var t = e.collections.sourceSizers,
							n = e.core.windowResizeActioner,
							o = (e.data, e.elements.smw),
							i = e.props.sourceMargin,
							s = e.stageIndexes,
							r = 1 - 2 * i;
						n.runActions = function () {
							(innerWidth > 992 ? (e.mw = r * innerWidth) : (e.mw = innerWidth),
								(e.mh = r * innerHeight));
							for (var n = 0; n < o.length; n++)
								(o[n].d(), t[n] && t[n].adjustSize());
							var i = s.previous,
								a = s.next;
							(void 0 !== i && o[i].ne(), void 0 !== a && o[a].p());
						};
					})(e));
			}
			function Q(e) {
				var t = e.ap,
					n = (e.componentsServices, e.core),
					o = n.globalEventsController,
					s = n.scrollbarRecompensor,
					r = n.sourceDisplayFacade,
					c = n.stageManager,
					u = n.windowResizeActioner,
					f = e.data,
					p = e.e,
					h = e.elements,
					g = (e.props, e.stageIndexes),
					b = e.sws,
					v = 0;
				function x() {
					var t,
						n,
						o = e.props,
						s = o.autoplay,
						r = o.autoplays;
					((v = !0),
						(function (e) {
							var t = e.props,
								n = t.autoplays;
							e.c = t.sources.length;
							for (var o = 0; o < e.c; o++)
								("false" === n[o] && (n[o] = 0), "" === n[o] && (n[o] = 1));
							((e.dss = t.disableSlideSwiping),
								(e.loc = t.loadOnlyCurrentSource),
								(e.ud = t.useDialog && "function" == typeof HTMLDialogElement));
						})(e),
						(f.scrollbarWidth = (function () {
							var e = document.createElement("div"),
								t = e.style,
								n = document.createElement("div");
							((t.visibility = "hidden"),
								(t.width = "100px"),
								(t.msOverflowStyle = "scrollbar"),
								(t.overflow = "scroll"),
								(n.style.width = "100%"),
								document.body.appendChild(e));
							var o = e.offsetWidth;
							e.appendChild(n);
							var i = n.offsetWidth;
							return (document.body.removeChild(e), o - i);
						})()),
						(s || r.length > 0) && (e.loc = 1),
						K(e),
						e.fs.i(),
						(h.container = document.createElement(e.ud ? "dialog" : "div")),
						(h.container.className = ""
							.concat(i, "container ")
							.concat(a, " ")
							.concat(m)),
						h.container.setAttribute("tabindex", "0"),
						(function (e) {
							var t = e.elements;
							((t.slideSwipingHoverer = document.createElement("div")),
								(t.slideSwipingHoverer.className = ""
									.concat(i, "slide-swiping-hoverer ")
									.concat(a, " ")
									.concat(d)));
						})(e),
						j(e),
						(function (e) {
							var t = e.core.sourcesPointerDown,
								n = e.elements,
								o = e.props.sources,
								i = document.createElement("div");
							((i.className = "".concat(d, " ").concat(a)),
								n.container.appendChild(i),
								i.addEventListener("pointerdown", t.listener),
								(n.sourceWrappersContainer = i));
							for (var s = 0; s < o.length; s++) H(e, s);
						})(e),
						e.props.sources.length > 1 &&
							((n = (t = e).core.slideChangeFacade),
							X(
								t,
								n.changeToPrevious,
								"previous",
								"M18.271,9.212H3.615l4.184-4.184c0.306-0.306,0.306-0.801,0-1.107c-0.306-0.306-0.801-0.306-1.107,0L1.21,9.403C1.194,9.417,1.174,9.421,1.158,9.437c-0.181,0.181-0.242,0.425-0.209,0.66c0.005,0.038,0.012,0.071,0.022,0.109c0.028,0.098,0.075,0.188,0.142,0.271c0.021,0.026,0.021,0.061,0.045,0.085c0.015,0.016,0.034,0.02,0.05,0.033l5.484,5.483c0.306,0.307,0.801,0.307,1.107,0c0.306-0.305,0.306-0.801,0-1.105l-4.184-4.185h14.656c0.436,0,0.788-0.353,0.788-0.788S18.707,9.212,18.271,9.212z",
							),
							X(
								t,
								n.changeToNext,
								"next",
								"M1.729,9.212h14.656l-4.184-4.184c-0.307-0.306-0.307-0.801,0-1.107c0.305-0.306,0.801-0.306,1.106,0l5.481,5.482c0.018,0.014,0.037,0.019,0.053,0.034c0.181,0.181,0.242,0.425,0.209,0.66c-0.004,0.038-0.012,0.071-0.021,0.109c-0.028,0.098-0.075,0.188-0.143,0.271c-0.021,0.026-0.021,0.061-0.045,0.085c-0.015,0.016-0.034,0.02-0.051,0.033l-5.483,5.483c-0.306,0.307-0.802,0.307-1.106,0c-0.307-0.305-0.307-0.801,0-1.105l4.184-4.185H1.729c-0.436,0-0.788-0.353-0.788-0.788S1.293,9.212,1.729,9.212z",
							)),
						(function (e) {
							for (
								var t = e.props.sources,
									n = e.resolve,
									o = n(L),
									i = n(R),
									s = n(M, [o, i]),
									r = 0;
								r < t.length;
								r++
							)
								if ("string" == typeof t[r]) {
									var a = s.getTypeSetByClientForIndex(r);
									if (a) i.runActionsForSourceTypeAndIndex(a, r);
									else {
										var c = o.getSourceTypeFromLocalStorageByUrl(t[r]);
										c
											? i.runActionsForSourceTypeAndIndex(c, r)
											: s.retrieveTypeWithXhrForIndex(r);
									}
								} else i.runActionsForSourceTypeAndIndex("custom", r);
						})(e),
						p("onInit"));
				}
				e.open = function () {
					var n =
							arguments.length > 0 && void 0 !== arguments[0]
								? arguments[0]
								: 0,
						i = g.previous,
						a = g.current,
						d = g.next;
					((g.current = n),
						v || S(e),
						c.updateStageIndexes(),
						v ? (b.c(), b.a(), b.b(i), b.b(a), b.b(d), p("onShow")) : x(),
						r.displaySourcesWhichShouldBeDisplayed(),
						e.sn(n + 1),
						document.body.appendChild(h.container),
						e.ud && h.container.showModal(),
						h.container.focus(),
						document.documentElement.classList.add(l),
						s.addRecompense(),
						o.attachListeners(),
						u.runActions(),
						h.smw[n].n(),
						t.p(n),
						p("onOpen"));
				};
			}
			function Z(e, t, n) {
				return (Z = ee()
					? Reflect.construct.bind()
					: function (e, t, n) {
							var o = [null];
							o.push.apply(o, t);
							var i = new (Function.bind.apply(e, o))();
							return (n && te(i, n.prototype), i);
						}).apply(null, arguments);
			}
			function ee() {
				if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
				if (Reflect.construct.sham) return !1;
				if ("function" == typeof Proxy) return !0;
				try {
					return (
						Boolean.prototype.valueOf.call(
							Reflect.construct(Boolean, [], function () {}),
						),
						!0
					);
				} catch (e) {
					return !1;
				}
			}
			function te(e, t) {
				return (te = Object.setPrototypeOf
					? Object.setPrototypeOf.bind()
					: function (e, t) {
							return ((e.__proto__ = t), e);
						})(e, t);
			}
			function ne(e) {
				return (
					(function (e) {
						if (Array.isArray(e)) return oe(e);
					})(e) ||
					(function (e) {
						if (
							("undefined" != typeof Symbol && null != e[Symbol.iterator]) ||
							null != e["@@iterator"]
						)
							return Array.from(e);
					})(e) ||
					(function (e, t) {
						if (!e) return;
						if ("string" == typeof e) return oe(e, t);
						var n = Object.prototype.toString.call(e).slice(8, -1);
						"Object" === n && e.constructor && (n = e.constructor.name);
						if ("Map" === n || "Set" === n) return Array.from(e);
						if (
							"Arguments" === n ||
							/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
						)
							return oe(e, t);
					})(e) ||
					(function () {
						throw new TypeError(
							"Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.",
						);
					})()
				);
			}
			function oe(e, t) {
				(null == t || t > e.length) && (t = e.length);
				for (var n = 0, o = new Array(t); n < t; n++) o[n] = e[n];
				return o;
			}
			function ie() {
				for (
					var e = document.getElementsByTagName("a"),
						t = function (t) {
							if (!e[t].hasAttribute("data-fslightbox")) return "continue";
							var n = e[t].hasAttribute("data-href")
								? e[t].getAttribute("data-href")
								: e[t].getAttribute("href");
							if (!n)
								return (
									console.warn(
										'The "data-fslightbox" attribute was set without the "href" attribute.',
									),
									"continue"
								);
							var o = e[t].getAttribute("data-fslightbox");
							fsLightboxInstances[o] ||
								(fsLightboxInstances[o] = new FsLightbox());
							var i = null;
							("#" === n.charAt(0)
								? (i = document
										.getElementById(n.substring(1))
										.cloneNode(!0)).removeAttribute("id")
								: (i = n),
								fsLightboxInstances[o].props.sources.push(i),
								fsLightboxInstances[o].elements.a.push(e[t]));
							var s = fsLightboxInstances[o].props.sources.length - 1;
							((e[t].onclick = function (e) {
								(e.preventDefault(), fsLightboxInstances[o].open(s));
							}),
								d("types", "data-type"),
								d("videosPosters", "data-video-poster"),
								d("customClasses", "data-class"),
								d("customClasses", "data-custom-class"),
								d("autoplays", "data-autoplay"));
							for (
								var r = [
										"href",
										"data-fslightbox",
										"data-href",
										"data-type",
										"data-video-poster",
										"data-class",
										"data-custom-class",
										"data-autoplay",
									],
									a = e[t].attributes,
									c = fsLightboxInstances[o].props.customAttributes,
									l = 0;
								l < a.length;
								l++
							)
								if (
									-1 === r.indexOf(a[l].name) &&
									"data-" === a[l].name.substr(0, 5)
								) {
									c[s] || (c[s] = {});
									var u = a[l].name.substr(5);
									c[s][u] = a[l].value;
								}
							function d(n, i) {
								e[t].hasAttribute(i) &&
									(fsLightboxInstances[o].props[n][s] = e[t].getAttribute(i));
							}
						},
						n = 0;
					n < e.length;
					n++
				)
					t(n);
				var o = Object.keys(fsLightboxInstances);
				window.fsLightbox = fsLightboxInstances[o[o.length - 1]];
			}
			((window.FsLightbox = function () {
				var e = this;
				((this.props = {
					sources: [],
					customAttributes: [],
					customClasses: [],
					autoplays: [],
					types: [],
					videosPosters: [],
					exitFullscreenOnClose: 1,
					sourceMargin: 0.05,
					slideDistance: 0.3,
				}),
					(this.data = { isFullscreenOpen: !1, scrollbarWidth: 0 }),
					(this.isl = []),
					(this.sourcePointerProps = {
						downScreenX: null,
						isPointering: !1,
						isSourceDownEventTarget: !1,
						swipedX: 0,
					}),
					(this.stageIndexes = {}),
					(this.elements = {
						a: [],
						container: null,
						slideSwipingHoverer: null,
						smw: [],
						sourceWrappersContainer: null,
						sources: [],
						sourceAnimationWrappers: [],
					}),
					(this.sn = function () {}),
					(this.resolve = function (t) {
						var n =
							arguments.length > 1 && void 0 !== arguments[1]
								? arguments[1]
								: [];
						return (n.unshift(e), Z(t, ne(n)));
					}),
					(this.collections = {
						sourceLoadHandlers: [],
						sourcesRenderFunctions: [],
						sourceSizers: [],
					}),
					(this.core = {
						globalEventsController: {},
						lightboxCloser: {},
						lightboxUpdater: {},
						scrollbarRecompensor: {},
						slideChangeFacade: {},
						slideIndexChanger: {},
						sourcesPointerDown: {},
						sourceDisplayFacade: {},
						stageManager: {},
						windowResizeActioner: {},
					}),
					(this.ap = {}),
					(this.fs = {}),
					(this.sws = {}),
					(this.e = function (t) {
						e.props[t] && e.props[t](e);
					}),
					Q(this),
					(this.close = function () {
						return e.core.lightboxCloser.closeLightbox();
					}));
			}),
				(window.fsLightboxInstances = {}),
				ie(),
				(window.refreshFsLightbox = function () {
					for (var e in fsLightboxInstances) {
						var t = fsLightboxInstances[e].props;
						((fsLightboxInstances[e] = new FsLightbox()),
							(fsLightboxInstances[e].props = t),
							(fsLightboxInstances[e].props.sources = []),
							(fsLightboxInstances[e].elements.a = []));
					}
					ie();
				}));
		},
	]);
});
